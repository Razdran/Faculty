package com.example.whitetile;

import android.app.ActionBar;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    ImageView tile1,tile2,tile3,tile4,tile5,tile6,tile7,tile8,tile9,tile10,tile11,tile12,tile13,tile14,tile15,tile16;
    int blackRow1,blackRow2,blackRow3,blackRow4;
    Handler h = new Handler();
    int delay = 1100; //1 second=1000 miliseconds
    Runnable runnable;
    boolean end=false;
    boolean lastRowCompleted=false;
    boolean lastButOneRowCompleted=false;
    int score=0;
    int highScore=0;
    int firstClick=0;
    MediaPlayer mp;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.mp=MediaPlayer.create(this,R.raw.furelise);

        score=0;
        highScore=getHighScore();

        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setCustomView(R.layout.my_action_bar);

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(Color.rgb(9, 69, 60)));
        displayHighScore();
        tile1=(ImageView) findViewById(R.id.tile1);
        tile2=(ImageView) findViewById(R.id.tile2);
        tile3=(ImageView) findViewById(R.id.tile3);
        tile4=(ImageView) findViewById(R.id.tile4);

        tile5=(ImageView) findViewById(R.id.tile5);
        tile6=(ImageView) findViewById(R.id.tile6);
        tile7=(ImageView) findViewById(R.id.tile7);
        tile8=(ImageView) findViewById(R.id.tile8);

        tile9=(ImageView) findViewById(R.id.tile9);
        tile10=(ImageView) findViewById(R.id.tile10);
        tile11=(ImageView) findViewById(R.id.tile11);
        tile12=(ImageView) findViewById(R.id.tile12);

        tile13=(ImageView) findViewById(R.id.tile13);
        tile14=(ImageView) findViewById(R.id.tile14);
        tile15=(ImageView) findViewById(R.id.tile15);
        tile16=(ImageView) findViewById(R.id.tile16);



        tile9.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tile9.setBackgroundColor(Color.GREEN);
                if(blackRow3!=1)
                {
                    tile9.setBackgroundColor(Color.RED);

                    h.removeCallbacks(runnable);
                    endGame();
                    end=true;
                }
                else
                {
                    mp.start();
                    score++;
                    firstClick=1;
                    setScore(score);
                    lastButOneRowCompleted=true;
                }
            }
        });


        tile10.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tile10.setBackgroundColor(Color.GREEN);
                if(blackRow3!=2)
                {
                    tile10.setBackgroundColor(Color.RED);
                    h.removeCallbacks(runnable);
                    endGame();
                    end=true;
                }
                else
                {
                    mp.start();
                    score++;

                    firstClick=1;
                    setScore(score);
                    lastButOneRowCompleted=true;
                }

            }
        });


        tile11.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tile11.setBackgroundColor(Color.GREEN);
                if(blackRow3!=3)
                {

                    tile11.setBackgroundColor(Color.RED);
                    h.removeCallbacks(runnable);
                    endGame();
                    end=true;
                }
                else
                {
                    mp.start();
                    lastButOneRowCompleted=true;
                    score++;

                    firstClick=1;
                    setScore(score);
                }

            }
        });


        tile12.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tile12.setBackgroundColor(Color.GREEN);
                if(blackRow3!=4)
                {

                    tile12.setBackgroundColor(Color.RED);
                    h.removeCallbacks(runnable);
                    endGame();
                    end=true;
                }
                else
                {
                    mp.start();
                    lastButOneRowCompleted=true;
                    score++;

                    firstClick=1;
                    setScore(score);
                }

            }
        });




        tile13.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tile13.setBackgroundColor(Color.GREEN);
                if(blackRow4!=1)
                {

                    mp.start();
                    tile13.setBackgroundColor(Color.RED);
                    h.removeCallbacks(runnable);
                    endGame();
                    end=true;
                }
                else
                {
                    mp.start();
                    lastRowCompleted=true;
                    score++;

                    firstClick=1;
                    setScore(score);
                }

            }
        });


        tile14.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tile14.setBackgroundColor(Color.GREEN);
                if(blackRow4!=2)
                {

                    tile14.setBackgroundColor(Color.RED);
                    h.removeCallbacks(runnable);
                    endGame();
                    end=true;
                }
                else
                {
                    mp.start();
                    lastRowCompleted=true;
                    score++;

                    firstClick=1;
                    setScore(score);
                }

            }
        });


        tile15.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tile15.setBackgroundColor(Color.GREEN);
                if(blackRow4!=3)
                {

                    tile15.setBackgroundColor(Color.RED);
                    h.removeCallbacks(runnable);
                    endGame();
                    end=true;
                }
                else
                {
                    mp.start();
                    lastRowCompleted=true;
                    score++;

                    firstClick=1;
                    setScore(score);
                }

            }
        });


        tile16.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tile16.setBackgroundColor(Color.GREEN);
                if(blackRow4!=4)
                {

                    tile16.setBackgroundColor(Color.RED);
                    h.removeCallbacks(runnable);
                    endGame();
                    end=true;
                }
                else
                {
                    mp.start();
                    lastRowCompleted=true;
                    score++;

                    firstClick=1;
                    setScore(score);
                }

            }
        });




        initGame();
        startGame();
    }

    public int getHighScore()
    {
        SharedPreferences prefs = this.getSharedPreferences("myPreferences", Context.MODE_PRIVATE);
        int Hscore = prefs.getInt("HighScorekey", 0);
        return Hscore;
    }
    public void setHighScore(int iscore)
    {
        highScore=iscore;
        SharedPreferences prefs = this.getSharedPreferences("myPreferences", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt("HighScorekey", iscore);
        editor.commit();
    }
     public void setScore(int iscore)
    {
        TextView TxtScore;
        TxtScore=(TextView) findViewById(R.id.acBarScore);
        TxtScore.setText("Score: "+iscore);
        if(score!=0&&score%10==0)
        {
            delay= delay-(delay/5);
        }
    }
    public void displayHighScore()
    {
        TextView TxtHScore;
        TxtHScore=(TextView) findViewById(R.id.acBarHighScore);
        TxtHScore.setText("High Score: "+highScore);
    }
    public void fillTileById(int id)
    {
     switch(id) {
         case 1:
             tile1.setBackgroundColor(Color.BLACK);
             break;
         case 2:
             tile2.setBackgroundColor(Color.BLACK);
             break;
         case 3:
             tile3.setBackgroundColor(Color.BLACK);
             break;
         case 4:
             tile4.setBackgroundColor(Color.BLACK);
             break;
         case 5:
             tile5.setBackgroundColor(Color.BLACK);
             break;
         case 6:
             tile6.setBackgroundColor(Color.BLACK);
             break;
         case 7:
             tile7.setBackgroundColor(Color.BLACK);
             break;
         case 8:
             tile8.setBackgroundColor(Color.BLACK);
             break;
         case 9:
             tile9.setBackgroundColor(Color.BLACK);
             break;
         case 10:
             tile10.setBackgroundColor(Color.BLACK);
             break;
         case 11:
             tile11.setBackgroundColor(Color.BLACK);
             break;
         case 12:
             tile12.setBackgroundColor(Color.BLACK);
             break;
         case 13:
             tile13.setBackgroundColor(Color.BLACK);
             break;
         case 14:
             tile14.setBackgroundColor(Color.BLACK);
             break;
         case 15:
             tile15.setBackgroundColor(Color.BLACK);
             break;
         case 16:
             tile16.setBackgroundColor(Color.BLACK);
             break;

         default:
             break;
     }
    }

    public void moveTiles()
    {

        if(lastRowCompleted!=true)
        {
            end=true;
            h.removeCallbacks(runnable);
            endGame();
        }
        else {

            allWhite();

            fillTileById(blackRow1 + 4);
            fillTileById(blackRow2 + 8);
            fillTileById(blackRow3 + 12);

            blackRow4 = blackRow3;
            blackRow3 = blackRow2;
            blackRow2 = blackRow1;

            blackRow1 = new Random().nextInt(4) + 1;
            while (blackRow1 == blackRow2)
                blackRow1 = new Random().nextInt(4) + 1;

            fillTileById(blackRow1);
            if(lastButOneRowCompleted==true)
            {
                switch(blackRow4){
                    case 1:
                        tile13.setBackgroundColor(Color.GREEN);
                        break;
                    case 2:
                        tile14.setBackgroundColor(Color.GREEN);
                        break;
                    case 3:
                        tile15.setBackgroundColor(Color.GREEN);
                        break;
                    case 4:
                        tile16.setBackgroundColor(Color.GREEN);
                        break;
                    default:
                        break;
                }
            }

            lastRowCompleted=lastButOneRowCompleted;
            lastButOneRowCompleted=false;
        }

    }

    public void allWhite(){

        tile1.setBackgroundColor(Color.WHITE);
        tile2.setBackgroundColor(Color.WHITE);
        tile3.setBackgroundColor(Color.WHITE);
        tile4.setBackgroundColor(Color.WHITE);

        tile5.setBackgroundColor(Color.WHITE);
        tile6.setBackgroundColor(Color.WHITE);
        tile7.setBackgroundColor(Color.WHITE);
        tile8.setBackgroundColor(Color.WHITE);

        tile9.setBackgroundColor(Color.WHITE);
        tile10.setBackgroundColor(Color.WHITE);
        tile11.setBackgroundColor(Color.WHITE);
        tile12.setBackgroundColor(Color.WHITE);

        tile13.setBackgroundColor(Color.WHITE);
        tile14.setBackgroundColor(Color.WHITE);
        tile15.setBackgroundColor(Color.WHITE);
        tile16.setBackgroundColor(Color.WHITE);



        tile1.setImageResource(R.drawable.border);
        tile2.setImageResource(R.drawable.border);
        tile3.setImageResource(R.drawable.border);
        tile4.setImageResource(R.drawable.border);

        tile5.setImageResource(R.drawable.border);
        tile6.setImageResource(R.drawable.border);
        tile7.setImageResource(R.drawable.border);
        tile8.setImageResource(R.drawable.border);

        tile9.setImageResource(R.drawable.border);
        tile10.setImageResource(R.drawable.border);
        tile11.setImageResource(R.drawable.border);
        tile12.setImageResource(R.drawable.border);

        tile13.setImageResource(R.drawable.border);
        tile14.setImageResource(R.drawable.border);
        tile15.setImageResource(R.drawable.border);
        tile16.setImageResource(R.drawable.border);



    }
    public void initGame(){
        allWhite();
        lastRowCompleted=false;
        lastButOneRowCompleted=false;
        blackRow1=new Random().nextInt(4)+1;

        blackRow2=new Random().nextInt(4)+1;
        while(blackRow1==blackRow2)
            blackRow2=new Random().nextInt(4)+1;

        blackRow3=new Random().nextInt(4)+1;
        while(blackRow2==blackRow3)
            blackRow3=new Random().nextInt(4)+1;

        blackRow4=new Random().nextInt(4)+1;
        while(blackRow3==blackRow4)
            blackRow4=new Random().nextInt(4)+1;

        fillTileById(blackRow1);
        fillTileById(blackRow2+4);
        fillTileById(blackRow3+8);
        fillTileById(blackRow4+12);
    }
    public void endGame(){
        if(mp.isPlaying())
            mp.stop();
        if(score>highScore)
        {
            setHighScore(score);
            displayHighScore();
        }
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setCancelable(false);

        alert.setTitle("Game ended!");
        alert.setMessage("You Lose! \n   Your score: "+Integer.toString(score));
        alert.setPositiveButton("OK",new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                // Finish activity
                finish();
            }
        });
        AlertDialog dialog=alert.show();
        dialog.setCanceledOnTouchOutside(false);

    }
    public void startGame(){

        h.postDelayed( runnable = new Runnable() {
            public void run() {

                h.postDelayed(runnable, delay);

                if(end!=false) {
                    h.removeCallbacks(runnable);
                    if(mp.isPlaying())
                        mp.stop();

                    endGame();
                }
                else {
                 if(firstClick!=0) {
                     moveTiles();
                     mp.pause();
                 }
                }
            }
        }, delay);
    }
    protected void onPause() {
        h.removeCallbacks(runnable); //stop handler when activity not visible
        if(mp.isPlaying())
            mp.stop();
        finish();
        super.onPause();

    }


}
