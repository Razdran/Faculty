package com.example.whitetile;

import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.SharePhoto;
import com.facebook.share.model.SharePhotoContent;
import com.facebook.share.widget.ShareDialog;

public class GameMenu extends AppCompatActivity {

    public int Hscore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SharedPreferences prefs = this.getSharedPreferences("myPreferences", Context.MODE_PRIVATE);
        this.Hscore = prefs.getInt("HighScorekey", 0);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_menu);

        TextView logo=(TextView) findViewById(R.id.logoText);
        logo.setTextColor(Color.WHITE);
        logo.setTextSize(50);

        TextView menuHscore=(TextView) findViewById(R.id.menuHighScore);
        menuHscore.setTextColor(Color.WHITE);
        menuHscore.setTextSize(35);
        menuHscore.setText("Your HighScore:\n"+Hscore);


        Button btn = (Button)findViewById(R.id.newGameBtn);

        Button facebookBtn = (Button)findViewById(R.id.facebookBtn);

        btn.setBackgroundColor(Color.WHITE);
        facebookBtn.setBackgroundColor(Color.WHITE);

        btn.setTextColor(Color.rgb(9, 69, 60));
        facebookBtn.setTextColor(Color.rgb(9, 69, 60));

        btn.setTextSize(20);
        facebookBtn.setTextSize(20);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(GameMenu.this, MainActivity.class));
            }
        });

        facebookBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startSharing();
            }
        });
        getSupportActionBar().hide();
        setActivityBackgroundColor(Color.rgb(9, 69, 60));
    }
    public void setActivityBackgroundColor(int color) {
        View view = this.getWindow().getDecorView();
        view.setBackgroundColor(color);
    }
    final ShareDialog shareDialog = new ShareDialog(this);


    public void startSharing()
    {
        if (shareDialog.canShow(ShareLinkContent.class)) {



            ShareLinkContent content = new ShareLinkContent.Builder()
                    .setContentUrl(Uri.parse("https://developers.facebook.com/apps/457909061638120"))
                    .setQuote("Hi! I Scored "+Hscore+" points on WhiteTile game made by Anton Dragos Razvan")
                    .build();






            shareDialog.show(content);
        }

    }

}
